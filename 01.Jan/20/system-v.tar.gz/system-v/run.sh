qemu-aarch64 -cpu max,sve=on,sve128=on ./chal
