print(eval(f"# {input('> ')}\n'Hi!'"))
